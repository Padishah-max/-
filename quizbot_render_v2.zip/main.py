
import os
import sqlite3
from dataclasses import dataclass
from typing import Dict, List, Optional
from telegram import Update, Poll, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, ApplicationBuilder,
    CommandHandler, ContextTypes,
    CallbackQueryHandler, PollAnswerHandler,
)

# ====================== CONFIG ======================
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
if not BOT_TOKEN:
    raise RuntimeError("Set TELEGRAM_BOT_TOKEN env var")

# Admin IDs as comma-separated env var, e.g. "123,456"
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "123456789").split(",") if x.strip().isdigit()}

# Five countries to choose from
COUNTRIES = [c.strip() for c in os.getenv("COUNTRIES", "Россия,Казахстан,Армения,Беларусь,Кыргызстан").split(",") if c.strip()]

# SQLite path (ephemeral on Render is fine for events)
DB_PATH = os.getenv("QUIZ_DB_PATH", "/tmp/quiz_antikontrafakt.db")

# Per-question time limit
QUESTION_SECONDS = int(os.getenv("QUESTION_SECONDS", "45"))

# Public URL for webhook — Render exposes RENDER_EXTERNAL_URL automatically
PUBLIC_URL = os.getenv("PUBLIC_URL") or os.getenv("RENDER_EXTERNAL_URL", "")

# ==================== DATA MODELS ===================
@dataclass
class Question:
    text: str
    options: List[str]
    correct_indices: List[int]
    multiple: bool = False

@dataclass
class QuizState:
    index: int = 0
    last_poll_message_id: Optional[int] = None
    last_poll_chat_id: Optional[int] = None
    timer_job_id: Optional[str] = None

# ===================== QUESTIONS ====================
QUESTIONS: List[Question] = [
    # Simple
    Question("Что такое «контрафакт»?",
             ["a) Любой дешевый товар","b) Поддельная или незаконно произведённая продукция","c) Продукт, сделанный в другой стране","d) Оригинальный бренд"], [1]),
    Question("Какой товар подделывают чаще всего?",
             ["a) Электронику","b) Лекарства","c) Одежду и обувь","d) Все перечисленное"], [3]),
    Question("Как потребитель может проверить подлинность товара в магазине?",
             ["a) Только по внешнему виду","b) Сканировать QR-код на упаковке","c) Попросить продавца подтвердить","d) Никак невозможно"], [1]),
    Question("Что такое акциз?",
             ["a) Специальный налог на определённые товары","b) Вид наклейки на упаковке","c) Скидка от производителя","d) Клеймо качества"], [0]),
    Question("Может ли поддельное лекарство продаваться даже в аптеке?",
             ["a) Нет, такого не бывает","b) Да, но риск очень низкий","c) Только в интернете","d) Только в нелегальных киосках"], [1]),
    Question("Какие последствия несет покупка нелегальных товаров?",
             ["a) Ущерб для бюджета страны","b) Риски для здоровья","c) Поддержка криминальных схем","d) Всё перечисленное"], [3]),
    Question("Должны ли детские товары проходить особую проверку качества?",
             ["a) Нет, достаточно обычной сертификации","b) Да, потому что они напрямую влияют на здоровье и безопасность детей","c) Только игрушки, но не одежда","d) Проверка нужна только импортным товарам"], [1]),
    Question("Что важнее: доступность произведений или права авторов?",
             ["a) Доступность","b) Права авторов","c) Баланс интересов","d) Не имеет значения"], [2]),
    Question("Кто должен бороться с контрафактом в первую очередь?",
             ["a) Государство","b) Бизнес","c) Потребители","d) Все вместе"], [3]),
    Question("Для чего нужны стандарты качества?",
             ["a) Чтобы усложнить жизнь бизнесу","b) Для рекламы товаров","c) Для защиты потребителей и обеспечения безопасности продукции","d) Чтобы товар был дороже"], [2]),
    # Hard
    Question("Какие признаки указывают на подделку? (несколько)",
             ["a) Слишком низкая цена","b) Ошибки на упаковке","c) Нет маркировки/QR-кода","d) Продаётся только в крупных магазинах"], [0,1,2], True),
    Question("Почему борьба с контрафактом важна государству? (несколько)",
             ["a) Угроза налоговым поступлениям","b) Вред здоровью","c) Снижение доверия к рынку","d) Потому что товары дешевле"], [0,1,2], True),
    Question("Защита ПО — что подходит?",
             ["a) Патент","b) Авторское право","c) Акциз","d) Товарный знак"], [1]),
    Question("Купили поддельное лекарство онлайн. Что делать?",
             ["a) Выбросить и забыть","b) Сообщить в надзор/производителю","c) Продать друзьям","d) Использовать всё равно"], [1]),
    Question("Как цифровая маркировка помогает?",
             ["a) Отслеживает путь товара","b) Упрощает рекламу","c) Декорирует упаковку","d) Делает товар дороже"], [0]),
    Question("Какие продукты чаще подделывают? (несколько)",
             ["a) Молочные","b) Специи","c) Минеральную воду","d) Соль"], [0,1,2], True),
    Question("Опасность «качественных реплик»? (несколько)",
             ["a) Дешевле — безопаснее","b) Нарушение прав бренда","c) Может не соответствовать стандартам","d) Это законно"], [1,2], True),
    Question("Почему потребитель способствует? (несколько)",
             ["a) Покупает ради экономии","b) Не проверяет подлинность","c) Не сообщает о нарушениях","d) Нет смартфона"], [0,1,2], True),
    Question("Где подделки опаснее всего? (несколько)",
             ["a) Лекарства","b) Детские товары","c) Продукты питания","d) Одежда"], [0,1,2], True),
    Question("Единая база ЕАЭС — плюсы? (несколько)",
             ["a) Легче проверять подлинность","b) Больше бюрократии","c) Обмен инфо между странами","d) Снижение доверия"], [0,2], True),
]

# ===================== DB =========================
def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            country TEXT
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS votes (
            poll_id TEXT,
            user_id INTEGER,
            question_index INTEGER,
            options TEXT,
            PRIMARY KEY (poll_id, user_id)
        );
    """)
    return conn

# ================= RUNTIME / HELPERS ==============
@dataclass
class Question:  # redeclare? (No, already declared above) -- but keep unique
    pass
# (Ignore accidental re-declare)

class _State:  # avoid typing issues in this quick builder
    pass

CHAT_STATE: Dict[int, 'QuizState'] = {}

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

async def ensure_state(chat_id: int) -> 'QuizState':
    if chat_id not in CHAT_STATE:
        CHAT_STATE[chat_id] = QuizState(index=0)
    return CHAT_STATE[chat_id]

async def schedule_timer(chat_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    state = await ensure_state(chat_id)
    if state.timer_job_id:
        try:
            context.job_queue.scheduler.remove_job(state.timer_job_id)
        except Exception:
            pass
        state.timer_job_id = None
    job = context.job_queue.run_once(auto_close_and_next, when=int(QUESTION_SECONDS), data={"chat_id": chat_id})
    state.timer_job_id = job.id

async def send_question_by_chat(chat_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    state = await ensure_state(chat_id)
    if state.index >= len(QUESTIONS):
        await context.bot.send_message(chat_id=chat_id, text="Вопросы закончились. /begin чтобы начать заново.")
        return
    q = QUESTIONS[state.index]
    if not q.multiple and len(q.correct_indices) == 1:
        msg = await context.bot.send_poll(
            chat_id=chat_id,
            question=f"Вопрос {state.index+1}/{len(QUESTIONS)}
{q.text}",
            options=q.options,
            type=Poll.QUIZ,
            correct_option_id=q.correct_indices[0],
            is_anonymous=False,
            allows_multiple_answers=False,
            open_period=int(QUESTION_SECONDS),
            explanation=f"Ответ покажем через {QUESTION_SECONDS} сек",
        )
    else:
        msg = await context.bot.send_poll(
            chat_id=chat_id,
            question=f"Вопрос {state.index+1}/{len(QUESTIONS)}
{q.text}",
            options=q.options,
            type=Poll.REGULAR,
            is_anonymous=False,
            allows_multiple_answers=True,
            open_period=int(QUESTION_SECONDS),
        )
    state.last_poll_message_id = msg.message_id
    state.last_poll_chat_id = chat_id
    await schedule_timer(chat_id, context)

# =================== COMMANDS ======================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user:
        u = update.effective_user
        with db() as conn:
            conn.execute(
                "INSERT INTO users(user_id, username, first_name, last_name) VALUES(?,?,?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name, last_name=excluded.last_name",
                (u.id, u.username, u.first_name, u.last_name),
            )
    kb = [[InlineKeyboardButton(text=c, callback_data=f"set_country:{c}") for c in COUNTRIES]]
    await update.message.reply_text(
        "Привет! Это бот викторины ‘Антиконтрафакт’. Выберите свою страну:",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "/begin — инициализировать
"
        "/next — отправить вопрос (45 сек)
"
        "/close — закрыть текущий
"
        "/register — выбрать/сменить страну
"
        "/stats — сводка по странам (админ)
"
        "/help — помощь"
    )

async def register(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    kb = [[InlineKeyboardButton(text=c, callback_data=f"set_country:{c}") for c in COUNTRIES]]
    await update.message.reply_text("Выберите вашу страну:", reply_markup=InlineKeyboardMarkup(kb))

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Статистика только для админа.")
        return
    with db() as conn:
        cur = conn.execute("SELECT country, COUNT(*) FROM users WHERE country IS NOT NULL GROUP BY country ORDER BY COUNT(*) DESC")
        users_per_country = cur.fetchall()
        cur = conn.execute("SELECT u.country, COUNT(v.user_id) FROM votes v JOIN users u ON u.user_id=v.user_id GROUP BY u.country ORDER BY COUNT(v.user_id) DESC")
        votes_per_country = cur.fetchall()
    fmt = lambda rows: "
".join([f"{c or '—'}: {n}" for c, n in rows]) or "нет данных"
    await update.message.reply_text("👥 Users by country:
" + fmt(users_per_country) + "

🗳️ Votes by country:
" + fmt(votes_per_country))

async def begin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Только администратор может начинать.")
        return
    state = await ensure_state(update.effective_chat.id)
    if state.timer_job_id:
        try:
            context.job_queue.scheduler.remove_job(state.timer_job_id)
        except Exception:
            pass
        state.timer_job_id = None
    state.index = 0
    state.last_poll_message_id = None
    state.last_poll_chat_id = None
    await update.message.reply_text("Викторина инициализирована. /next для первого вопроса.")

async def next_q(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Только администратор может отправлять вопросы.")
        return
    await send_question_by_chat(update.effective_chat.id, context)

async def close_poll(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Только администратор может закрывать опрос.")
        return
    chat_id = update.effective_chat.id
    state = await ensure_state(chat_id)
    if state.timer_job_id:
        try:
            context.job_queue.scheduler.remove_job(state.timer_job_id)
        except Exception:
            pass
        state.timer_job_id = None
    if not state.last_poll_message_id:
        await update.message.reply_text("Нет активного опроса.")
        return
    stopped = None
    try:
        stopped = await context.bot.stop_poll(chat_id=state.last_poll_chat_id, message_id=state.last_poll_message_id)
    except Exception:
        pass
    if stopped is not None:
        await reveal_correct(chat_id, context, QUESTIONS[state.index], stopped)
    state.index += 1
    state.last_poll_message_id = None
    if state.index < len(QUESTIONS):
        await send_question_by_chat(chat_id, context)
    else:
        await context.bot.send_message(chat_id=chat_id, text="Викторина завершена! Спасибо.")

# ================== REVEAL & JOB ====================
async def reveal_correct(chat_id: int, context: ContextTypes.DEFAULT_TYPE, question, poll_result) -> None:
    letters = [chr(ord('A') + i) for i in range(len(question.options))]
    correct_letters = ", ".join(letters[i] for i in question.correct_indices)
    lines = []
    if poll_result:
        total_votes = sum(opt.voter_count for opt in poll_result.options)
        for i, opt in enumerate(poll_result.options):
            pct = (opt.voter_count / total_votes * 100) if total_votes else 0
            lines.append(f"{letters[i]}) {question.options[i]} — {opt.voter_count} голос(ов), {pct:.1f}%")
    stats_text = "
".join(lines) if lines else "Нет данных."
    await context.bot.send_message(
        chat_id=chat_id,
        text=("✅ Правильный ответ:" if not question.multiple else "✅ Правильные ответы:") +
             f" {correct_letters}

⏱ Время вышло ({QUESTION_SECONDS} сек).

📊 Результаты:
{stats_text}"
    )

async def auto_close_and_next(context: ContextTypes.DEFAULT_TYPE) -> None:
    data = context.job.data or {}
    chat_id = data.get("chat_id")
    if chat_id is None:
        return
    state = await ensure_state(chat_id)
    stopped = None
    if state.last_poll_message_id:
        try:
            stopped = await context.bot.stop_poll(chat_id=state.last_poll_chat_id, message_id=state.last_poll_message_id)
        except Exception:
            pass
    if stopped is not None and state.index < len(QUESTIONS):
        await reveal_correct(chat_id, context, QUESTIONS[state.index], stopped)
    state.index += 1
    state.last_poll_message_id = None
    state.timer_job_id = None
    if state.index < len(QUESTIONS):
        await send_question_by_chat(chat_id, context)
    else:
        await context.bot.send_message(chat_id=chat_id, text="Викторина завершена! Спасибо за участие.")

# ================== BUTTONS & VOTES =================
async def on_poll_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    pa = update.poll_answer
    if not pa:
        return
    user_id = pa.user.id
    with db() as conn:
        cur = conn.execute("SELECT country FROM users WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        if not row or not row[0]:
            try:
                await context.bot.send_message(chat_id=user_id, text="Чтобы учесть ваш голос по стране, отправьте /register и выберите страну.")
            except Exception:
                pass
            return
        conn.execute(
            "INSERT OR REPLACE INTO votes(poll_id, user_id, question_index, options) VALUES(?,?,?,?)",
            (pa.poll_id, user_id, -1, ",".join(map(str, pa.option_ids))),
        )

async def on_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cq = update.callback_query
    if not cq:
        return
    data = cq.data or ""
    if data.startswith("set_country:"):
        country = data.split(":", 1)[1]
        if country not in COUNTRIES:
            await cq.answer("Страна не из списка", show_alert=True)
            return
        with db() as conn:
            conn.execute(
                "INSERT INTO users(user_id, username, first_name, last_name, country) VALUES(?,?,?,?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET country=excluded.country, username=excluded.username, first_name=excluded.first_name, last_name=excluded.last_name",
                (cq.from_user.id, cq.from_user.username, cq.from_user.first_name, cq.from_user.last_name, country)
            )
        await cq.answer("Страна сохранена")
        await cq.edit_message_text(f"Вы выбрали: {country}")

# ================== BOOTSTRAP =======================
def build_app() -> Application:
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("register", register))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("begin", begin))
    app.add_handler(CommandHandler("next", next_q))
    app.add_handler(CommandHandler("close", close_poll))
    app.add_handler(CallbackQueryHandler(on_button))
    app.add_handler(PollAnswerHandler(on_poll_answer))
    return app

if __name__ == "__main__":
    application = build_app()
    port = int(os.getenv("PORT", "10000"))
    webhook_path = f"/{BOT_TOKEN}"
    if PUBLIC_URL:
        application.run_webhook(
            listen="0.0.0.0",
            port=port,
            url_path=webhook_path,
            webhook_url=PUBLIC_URL + webhook_path,
        )
    else:
        application.run_webhook(
            listen="0.0.0.0",
            port=port,
            url_path=webhook_path,
        )
