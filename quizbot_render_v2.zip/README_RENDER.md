
# Render (Free) — Telegram Quiz Bot

## Deploy
1) Create a GitHub repo and commit two files from this ZIP: `main.py`, `requirements.txt`.
2) On https://render.com → New → Web Service → connect your repo.
3) Start Command: `python main.py`
4) Environment:
   - `TELEGRAM_BOT_TOKEN` — token from @BotFather
   - `ADMIN_IDS` — your Telegram user id(s), e.g. `123456789`
   - (opt) `QUESTION_SECONDS` — `45`
   - (opt) `COUNTRIES` — `Россия,Казахстан,Армения,Беларусь,Кыргызстан`
5) Deploy. Render sets `RENDER_EXTERNAL_URL`; webhook is set to `<RENDER_EXTERNAL_URL>/<BOT_TOKEN>` automatically.

## Use
- Open `https://t.me/<your_bot_username>` and press Start.
- Admin: `/begin`, then `/next` — each question auto-closes after 45s and next question is posted.
